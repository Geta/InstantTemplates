//>>built
define("dojo/errors/RequestError",["./create"],function(_1){return _1("RequestError",function(_2,_3){this.response=_3;});});