define("epi-cms/component/SharedBlocks", [
// dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",

    "dojo/on",
    "dojo/when",
// epi
    "epi-cms/widget/HierarchicalList",
    "epi-cms/component/SharedBlocksViewModel",
// resources
    "epi/i18n!epi/cms/nls/episerver.cms.components.createblock",
    "epi/i18n!epi/cms/nls/contenttypes.blockdata"
],

function (
// dojo
    array,
    declare,
    lang,

    on,
    when,
// epi
    HierarchicalList,
    SharedBlocksViewModel,
// resources
    componentResources,
    res
) {

    return declare([HierarchicalList], {
        // summary:
        //      Shared blocks component
        // tags:
        //      internal

        // showCreateContentArea: [public] Boolean
        //      Flag which indicates whether the create content area should be displayed on startup.
        showCreateContentArea: false,

        modelClassName: SharedBlocksViewModel,

        noDataMessage: componentResources.nocontent,

        // hierarchicalListClass: [readonly] String
        //      The CSS class to be used on the content list.
        hierarchicalListClass: "epi-blockList",

        // createContentIcon: [public] String
        //      The icon class to be used in the create content area of the list.
        createContentIcon: "epi-iconPlus",

        // createContentText: [public] String
        createContentText: res.create,

        postCreate: function () {

            this.inherited(arguments);

            // show/hide createContentArea only when grid refreshes
            this.own(
               this.list.grid.on("dgrid-refresh-complete", lang.hitch(this, function (/*Event*/evt) {
                   when(evt.results, lang.hitch(this, function (results) {
                       // hide the contentarea on grid refresh only if grid has any item at all. Otherwise use the canExecute
                       var showCreateContentArea = results.length > 0 ? false : this.model.getCommand("newBlockDefault").get("canExecute");
                       this._toggleCreateContentArea(showCreateContentArea);
                   }));
               }))
            );
        },

        _onCreateAreaClick: function() {
            // summary:
            //      A callback function which is executed when the create area is clicked.
            // tags:
            //      protected
            this.inherited(arguments);
            this.model._commandRegistry.newBlockDefault.command.execute();
        },

        // =======================================================================
        // List setup

        _setupList: function () {

            this.inherited(arguments);

            var registry = this.model._commandRegistry,
                listWidget = this.list;

            this.own(
                on(listWidget, "copyOrCut", function copyOrCuthandler(copy) {
                    copy ? registry.copy.command.execute() : registry.cut.command.execute();
                }),
                on(listWidget, "delete", function () {
                    registry["delete"].command.execute();
                })
            );
        }

    });

});
