﻿/* Required need to get the needed resource root before subnodes */
/* First requires the module to stop IE from balking when language resources are cached on client */
require(["epi/i18n", "epi/i18n!epi/packaging/nls/EPiServer.Packaging.UI"]);